const MainClient = require("./bott");
const client = new MainClient();

client.connect()

module.exports = client; 