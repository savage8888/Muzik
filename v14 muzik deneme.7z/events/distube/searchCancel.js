module.exports = async (client, message, query) => {
    message.channel.send(`31 iptal.`);
}

// Lrows