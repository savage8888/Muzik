require("dotenv").config();

module.exports = {
    TOKEN: process.env.TOKEN || "MTAxNjA1MjI5OTkzMzcwMDIxNg.Gj9vHM.BySk5YQPqcym8dvr22gs2ucrQnpSEJVSZ46MxY",  // lrows token
    PREFIX: process.env.PREFIX || "!", // lrows prefix
    SAHİP: process.env.SAHİP || "898281297796005888", //lrows id
}